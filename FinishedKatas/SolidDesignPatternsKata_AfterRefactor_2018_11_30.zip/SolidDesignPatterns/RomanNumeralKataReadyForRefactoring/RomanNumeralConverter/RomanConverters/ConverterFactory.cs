﻿using RomanNumeralConverter.RomanConverters.NumberToRoman;
using RomanNumeralConverter.RomanConverters.RomanToNumber;
using RomanNumeralConverter.RomanConverters.RomanToNumber.HandlerFactory;

namespace RomanNumeralConverter.RomanConverters
{
    public class ConverterFactory
    {
        public IConverter CreateConverter(string input)
        {
            if (IsAnInteger(input))
            {
                return new NumberToRomanConverter();
            }
            else
            {
                return new RomanToNumberConverter(new RomanHandlerFactory());
            }
        }

        private bool IsAnInteger(string input)
        {
            return int.TryParse(input, out int convertedInt);
        }
    }
}
