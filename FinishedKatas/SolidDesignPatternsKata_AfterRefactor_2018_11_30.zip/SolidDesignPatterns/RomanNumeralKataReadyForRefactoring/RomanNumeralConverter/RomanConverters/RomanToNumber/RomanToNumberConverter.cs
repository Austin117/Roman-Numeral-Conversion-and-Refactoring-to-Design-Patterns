﻿using System.Linq;
using RomanNumeralConverter.RomanConverters.RomanToNumber.HandlerFactory;

namespace RomanNumeralConverter.RomanConverters.RomanToNumber
{
    public class RomanToNumberConverter : IConverter
    {
        private readonly RomanHandlerFactory _factory;
         
        public RomanToNumberConverter(RomanHandlerFactory romanHandlerFactory)
        {
            _factory = romanHandlerFactory;
        }

        public string Convert(string itemToConvert)
        {
            return ConvertRomanNumeralToInteger(itemToConvert);
        }

        private string ConvertRomanNumeralToInteger(string input)
        {
            var data = new RomanHandlerData
            {
                Input = input,
                RomanNumeralConvertedToInt = 0
            };
            var romanHandlers = _factory.CreateHandlers();
            foreach (var handler in romanHandlers) 
            {
                data = handler.HandleARoman(data);
            }

            return data.RomanNumeralConvertedToInt.ToString();
        }
    }

    public struct RomanHandlerData
    {
        public string Input { get; set; }
        public int RomanNumeralConvertedToInt { get; set; }
    }
}
