﻿namespace RomanNumeralConverter.RomanConverters.RomanToNumber.RomanHandlers
{
    public class HandleXL : IRomanHandler
    {
        public RomanHandlerData HandleARoman(RomanHandlerData data)
        {
            if (data.Input.Contains("XL"))
            {
                data.Input = data.Input.Replace("XL", "");
                data.RomanNumeralConvertedToInt += 40;
            }
            return data;
        }
    }
}