﻿using System.Linq;

namespace RomanNumeralConverter.RomanConverters.RomanToNumber.RomanHandlers
{
    public class HandleX : IRomanHandler
    {
        public RomanHandlerData HandleARoman(RomanHandlerData data)
        {
            var numberOfXs = data.Input.Count(x => x == 'X');
            data.Input = data.Input.Replace("X", "");
            data.RomanNumeralConvertedToInt += numberOfXs * 10;
            return data;
        }

    }
}