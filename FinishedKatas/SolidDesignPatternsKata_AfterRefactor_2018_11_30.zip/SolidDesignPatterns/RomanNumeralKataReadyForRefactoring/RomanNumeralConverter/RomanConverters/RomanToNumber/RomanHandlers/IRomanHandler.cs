﻿namespace RomanNumeralConverter.RomanConverters.RomanToNumber.RomanHandlers
{
    public interface IRomanHandler
    {
        RomanHandlerData HandleARoman(RomanHandlerData data);
    }
}
