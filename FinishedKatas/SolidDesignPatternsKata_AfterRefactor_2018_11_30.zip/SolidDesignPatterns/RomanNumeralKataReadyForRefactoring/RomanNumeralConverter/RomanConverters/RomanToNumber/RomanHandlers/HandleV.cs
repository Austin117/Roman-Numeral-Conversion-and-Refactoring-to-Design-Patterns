﻿namespace RomanNumeralConverter.RomanConverters.RomanToNumber.RomanHandlers
{
    public class HandleV : IRomanHandler
    {
        public RomanHandlerData HandleARoman(RomanHandlerData data)
        {
            if (data.Input.Contains("V"))
            {
                data.Input = data.Input.Replace("V", "");
                data.RomanNumeralConvertedToInt += 5;
            }
            return data;
        }
    }
}