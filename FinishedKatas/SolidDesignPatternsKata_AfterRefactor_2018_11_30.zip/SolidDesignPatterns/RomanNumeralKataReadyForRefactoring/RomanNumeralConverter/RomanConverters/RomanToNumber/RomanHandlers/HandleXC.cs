﻿
namespace RomanNumeralConverter.RomanConverters.RomanToNumber.RomanHandlers
{
    public class HandleXC : IRomanHandler
    {

        public RomanHandlerData HandleARoman(RomanHandlerData data)
        {
            if (data.Input.Contains("XC"))
            {
                data.Input = data.Input.Replace("XC", "");
                data.RomanNumeralConvertedToInt += 90;
            }
            return data;
        }
    }
}
