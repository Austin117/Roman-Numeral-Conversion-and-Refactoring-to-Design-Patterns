﻿namespace RomanNumeralConverter.RomanConverters.RomanToNumber.RomanHandlers
{
    public class HandleL : IRomanHandler
    {
  
        public RomanHandlerData HandleARoman(RomanHandlerData data)
        {
            if (data.Input.Contains("L"))
            {
                data.Input = data.Input.Replace("L", "");
                data.RomanNumeralConvertedToInt += 50;
            }

            return data;
        }
    }
}