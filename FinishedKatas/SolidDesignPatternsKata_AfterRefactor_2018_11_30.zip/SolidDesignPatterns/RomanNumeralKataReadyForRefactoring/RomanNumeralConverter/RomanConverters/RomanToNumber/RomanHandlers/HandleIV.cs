﻿namespace RomanNumeralConverter.RomanConverters.RomanToNumber.RomanHandlers
{
    public class HandleIV : IRomanHandler
    {
        public RomanHandlerData HandleARoman(RomanHandlerData data)
        {
            if (data.Input.Contains("IV"))
            {
                data.Input = data.Input.Replace("IV", "");
                data.RomanNumeralConvertedToInt += 4;
            }

            return data;
        }
    }
}