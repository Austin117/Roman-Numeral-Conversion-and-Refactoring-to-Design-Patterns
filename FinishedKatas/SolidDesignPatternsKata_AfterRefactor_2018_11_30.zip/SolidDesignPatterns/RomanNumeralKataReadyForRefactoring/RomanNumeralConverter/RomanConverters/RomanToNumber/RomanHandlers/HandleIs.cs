﻿namespace RomanNumeralConverter.RomanConverters.RomanToNumber.RomanHandlers
{
    public class HandleIs : IRomanHandler
    {
        public RomanHandlerData HandleARoman(RomanHandlerData data)
        {
            while (data.Input.Contains("I"))
            {
                data.Input = RemoveOneCharacter(data.Input);
                data.RomanNumeralConvertedToInt++;
            }

            return data;
        }

        private string RemoveOneCharacter(string input)
        {
            input = input.Substring(1);
            return input;
        }
    }
}