﻿namespace RomanNumeralConverter.RomanConverters.RomanToNumber.RomanHandlers
{
    public class HandleIX : IRomanHandler
    {
        public RomanHandlerData HandleARoman(RomanHandlerData data)
        {
            if (data.Input.Contains("IX"))
            {
                data.Input = data.Input.Replace("IX", "");
                data.RomanNumeralConvertedToInt += 9;
            }

            return data;
        }
    }
}