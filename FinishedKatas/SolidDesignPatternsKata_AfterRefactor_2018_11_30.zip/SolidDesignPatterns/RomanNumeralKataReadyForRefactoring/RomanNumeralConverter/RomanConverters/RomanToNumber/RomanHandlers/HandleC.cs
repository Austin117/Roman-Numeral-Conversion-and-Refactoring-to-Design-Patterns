﻿using System.Linq;

namespace RomanNumeralConverter.RomanConverters.RomanToNumber.RomanHandlers
{
    public class HandleC : IRomanHandler
    {

        public RomanHandlerData HandleARoman(RomanHandlerData data)
        {
            var numberOfCs = data.Input.Count(x => x == 'C');
            data.Input = data.Input.Replace("C", "");
            data.RomanNumeralConvertedToInt += numberOfCs * 100;
            return data;
        }
    }
}