﻿using System.Collections.Generic;
using RomanNumeralConverter.RomanConverters.RomanToNumber.RomanHandlers;

namespace RomanNumeralConverter.RomanConverters.RomanToNumber.HandlerFactory
{
    public class RomanHandlerFactory
    {

        public List<IRomanHandler> CreateHandlers()
        {
            List<IRomanHandler> _romanHandlers;

            // if string contains an I, return 
            _romanHandlers = new List<IRomanHandler>();
            _romanHandlers.Add(new HandleXC());
            _romanHandlers.Add(new HandleC());
            _romanHandlers.Add(new HandleXL());
            _romanHandlers.Add(new HandleL());
            _romanHandlers.Add(new HandleIX());
            _romanHandlers.Add(new HandleX());
            _romanHandlers.Add(new HandleIV());
            _romanHandlers.Add(new HandleV());
            _romanHandlers.Add(new HandleIs());

            return _romanHandlers;
        }
    }
}