﻿namespace RomanNumeralConverter.RomanConverters
{
    public interface IConverter
    {
        string Convert(string itemToConvert);
    }
}