﻿using System.Collections.Generic;

namespace RomanNumeralConverter.RomanConverters.NumberToRoman
{
    public class NumberToRomanConverter : IConverter

    {
        private int _intToConvert;
        private string _intConvertedToRomanNumeral;
        private readonly Dictionary<string, string> _romanToNumberDictionary = new Dictionary<string, string>()
        {
            {"V", "IIIII"},
            {"IV", "IIII"},
            {"X", "VV"},
            {"IX", "VIV"},
            {"L", "XXXXX"},
            {"XL", "XXXX"},
            {"C", "LL"},
            {"XC", "LXL"},
        };
        public string Convert(string itemToConvert)
        {
            return ConvertIntegerToRomanNumeral(itemToConvert);
        }
        private string ConvertIntegerToRomanNumeral(string input)
        {
            Init(input);
            ExplodeIntegerToAllIs();
            ReplaceIsWithRomanDictionaryEntries();

            return _intConvertedToRomanNumeral;
        }
        private void Init(string input)
        {
            int.TryParse(input, out _intToConvert);
            _intConvertedToRomanNumeral = "";
        }

        private void ExplodeIntegerToAllIs()
        {
            for (int i = 0; i < _intToConvert; i++)
                _intConvertedToRomanNumeral += "I";
        }

        private void ReplaceIsWithRomanDictionaryEntries()
        {
            foreach (var entry in _romanToNumberDictionary)
                _intConvertedToRomanNumeral = _intConvertedToRomanNumeral.Replace(entry.Value, entry.Key);
        }
    }
}
