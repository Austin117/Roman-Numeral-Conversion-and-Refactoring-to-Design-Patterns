﻿using RomanNumeralConverter.RomanConverters;

namespace RomanNumeralConverter
{
	public class RomanNumeralConverter
	{	
	    private readonly ConverterFactory _factory;
        
	    public RomanNumeralConverter(ConverterFactory factory)
        {
            _factory = factory;
        }

        public string Convert(string input)
		{
		    var converter = _factory.CreateConverter(input);
		    return converter.Convert(input);
		}
	}

}
