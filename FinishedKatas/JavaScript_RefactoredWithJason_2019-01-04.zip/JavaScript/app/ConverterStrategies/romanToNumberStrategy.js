function RomanToNumberStrategy(){
    this._romanToNumberDictionary =
    [
        { Roman: 'IX', Number: 9 }, 
        { Roman: 'X', Number: 10 },
        { Roman: 'IV', Number: 4 },
        { Roman: 'V', Number: 5 },
        { Roman: 'I', Number: 1 }
    ];    
}

RomanToNumberStrategy.prototype = {
    convert: function(input){
        var romanNumeral = input;
        var runningTotal = 0;
        while (this.thereAreRomanNumeralsLeft(romanNumeral)) {
            for (var i = 0; i < this._romanToNumberDictionary.length; i++) {
                var entry = this._romanToNumberDictionary[i];
                if (romanNumeral.includes(entry.Roman)) {
                    romanNumeral = romanNumeral.replace(entry.Roman, '');
                    runningTotal += entry.Number;
                }
            }
        }
        return runningTotal.toString();        
    },
    thereAreRomanNumeralsLeft: function(romanNumeral){
        return romanNumeral != "";
    }
};

module.exports = RomanToNumberStrategy;