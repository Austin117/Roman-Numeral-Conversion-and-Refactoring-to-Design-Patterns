function NumberToRomanStrategy(){
    this._numberToRomanDictionary =
        [
            { Roman: 'X', Number: 10 },
            { Roman: 'IX', Number: 9 },
            { Roman: 'V', Number: 5 },
            { Roman: 'IV', Number: 4 },
            { Roman: 'I', Number: 1 }
        ];    
}

NumberToRomanStrategy.prototype.convert = function(input){
    var number = Number(input);
    var romanNumeral = "";
    while (number != 0) {
        for (var i = 0; i < this._numberToRomanDictionary.length; i++) {
            var entry = this._numberToRomanDictionary[i];
            while (number >= entry.Number) {
                romanNumeral += entry.Roman;
                number -= entry.Number;
            }
        }
    }
    return romanNumeral;        
};

module.exports = NumberToRomanStrategy;