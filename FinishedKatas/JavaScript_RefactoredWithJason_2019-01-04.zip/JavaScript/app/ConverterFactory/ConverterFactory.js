const RomanToNumberStrategy = require("../ConverterStrategies/RomanToNumberStrategy.js");
const NumberToRomanStrategy = require("../ConverterStrategies/NumberToRomanStrategy.js");

var ConverterFactory = (function() {
    function ConverterFactory() {};

    ConverterFactory.prototype.create = function(input){
        if (this.isARomanNumeral(input))
            return new RomanToNumberStrategy();
        else
            return new NumberToRomanStrategy();
    };

    ConverterFactory.prototype.isARomanNumeral = function(input){
        return isNaN(Number(input));
    };

    return ConverterFactory;
})();

module.exports = ConverterFactory;