var Tacitus = (function(){
    
    function Tacitus(converterFactory){
        this._converterFactory = converterFactory;  
    }

    Tacitus.prototype.convert =  function(input){
        var converterStrategy = this._converterFactory.create(input);
        var convertedValue = converterStrategy.convert(input);
        return convertedValue;
    };

    return Tacitus;
})();

module.exports = Tacitus;