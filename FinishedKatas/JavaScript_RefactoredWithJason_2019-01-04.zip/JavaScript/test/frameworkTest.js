var expect = require("chai").expect;

describe('mocha works', function () {
    it('first test', function () {
        expect(true).to.equal(true);
    });
});